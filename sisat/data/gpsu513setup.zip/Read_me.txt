GPS UTILITY - README FILE

Version 5.13              7th March 2012

You will have unzipped this package and found this file and 
the self install EXE file, "gpsu511setup.exe".

Place the EXE file in a suitable folder and execute it by double 
clicking on the icon.

This will then install GPS Utility, the support, documentation 
and sample files. 

You will also obtain another README file with further instructions.  

If you are upgrading and have you own versions of symbol, 
grid or datums files then make sure you back them up first
as the installation will overwrite your existing files. 

The normal program installation folder for GPSU is 
      C:/Program Files/GPS Utility 

-------------------------------------------------------------------
Good GPSing.
Alan Murphy   -   murphy@gpsu.co.uk
