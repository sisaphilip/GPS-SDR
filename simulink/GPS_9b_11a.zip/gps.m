% run GPS example selector 
example_sel2html('GPS_sel.txt')